import React from 'react';

export function PricingFooter() {
  return (
    <p className="mt-16 text-center text-sm text-gray-400">
      * Pricing shown is for single-location practices. Contact us for multi-location pricing.
    </p>
  );
}