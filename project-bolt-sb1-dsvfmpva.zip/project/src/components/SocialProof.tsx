import React from 'react';

export function SocialProof() {
  return null;
}